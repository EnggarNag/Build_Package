class InputBilangan():
    def __init__(self, x, y):
        self.x = x
        self.y = y

    def kali(self):
        return self.x * self.y

    def bagi(self):
        return self.x / self.y

    def jumlah(self):
        return self.x + self.y

    def kurang(self):
        return self.x - self.y
