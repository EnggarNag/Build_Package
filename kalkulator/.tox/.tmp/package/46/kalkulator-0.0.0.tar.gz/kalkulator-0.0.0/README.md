# **Kalkulator**

Package yang saya buat adalah Package kalkulator sederhana berisikan modul untuk melakukan perhitungan operasi dasar aritmatika dan perhitungan BMI

## Aritmatika

didalam modul aritmatika terdapat 4 fungsi utama yaitu :

1. Perkalian
2. Pembagian
3. Penjumlahan
4. Pengurangan

Catatan
untuk file test aritmatika saat mengimpor modul dengan cara

> from kalkulator.aritmatika import \*

flake8 mendeteksi kesalahan (undefined names) namun saat program dijalankan tidak ada masalah.
maka dari itu untuk kerapihan codingan saya memutuskan untuk mengimpor satu per satu

## BMI

BMI (Body Mass Index) adalah skala ukuran untuk menentukan proporsi berat badan seseorang berdasarkan tinggi badan.
rumus BMI
BMI = Berat Badan / (Tinggi Badan \* Tinggi Badan)

Author : Enggar Lanang Nandhito Agil Ghibran
